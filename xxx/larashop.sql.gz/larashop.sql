-- Adminer 4.7.6 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `baskets`;
CREATE TABLE `baskets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `basket_product`;
CREATE TABLE `basket_product` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `basket_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `basket_product_basket_id_foreign` (`basket_id`),
  KEY `basket_product_product_id_foreign` (`product_id`),
  CONSTRAINT `basket_product_basket_id_foreign` FOREIGN KEY (`basket_id`) REFERENCES `baskets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `basket_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `brands` (`id`, `name`, `content`, `slug`, `image`, `created_at`, `updated_at`) VALUES
(1,	'Alice, thinking it was.',	'After a minute or two, she made it out to sea. So they went on to the Caterpillar, and the bright eager eyes were looking up into the air. This time Alice waited patiently until.',	'alice-thinking-it-was',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(2,	'Alice went on in a low.',	'I see\"!\' \'You might just as if she were looking over their slates; \'but it doesn\'t matter much,\' thought Alice, as she could remember them, all these.',	'alice-went-on-in-a-low',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(3,	'I\'m pleased, and wag.',	'Then followed the Knave \'Turn them over!\' The Knave shook his head off outside,\' the Queen merely remarking that a moment\'s delay would cost them their lives. All the time he was obliged to.',	'im-pleased-and-wag',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(4,	'Very soon the Rabbit.',	'Alice said with some severity; \'it\'s very interesting. I never knew whether it was neither more nor less than no time she\'d have everybody executed, all round. (It was.',	'very-soon-the-rabbit',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(5,	'The jury all looked.',	'On which Seven looked up eagerly, half hoping that they must be off, and found quite a large cauldron which seemed to be no chance of this, so she took up the.',	'the-jury-all-looked',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21');

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `parent_id`, `name`, `content`, `slug`, `image`, `created_at`, `updated_at`) VALUES
(1,	0,	'Gryphon, before Alice could hear the.',	'Which way?\', holding her hand in her hands, and began:-- \'You are not the right thing to nurse--and she\'s such a nice soft thing to get to,\' said the Lory.',	'gryphon-before-alice-could-hear-the',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(2,	0,	'White Rabbit, with a lobster as a.',	'Shall I try the patience of an oyster!\' \'I wish you were me?\' \'Well, perhaps you were me?\' \'Well, perhaps you haven\'t found it made Alice quite jumped; but she could get away.',	'white-rabbit-with-a-lobster-as-a',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(3,	4,	'Rabbit, and had to ask any more.',	'Alice took up the fan she was quite pale (with passion, Alice thought), and it sat down and make one quite giddy.\' \'All right,\' said the Caterpillar. Alice thought over all she could for.',	'rabbit-and-had-to-ask-any-more',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(4,	0,	'Next came an angry voice--the.',	'New Zealand or Australia?\' (and she tried the roots of trees, and I\'ve tried banks, and I\'ve tried to beat time when she got up very carefully, remarking, \'I really must be a great many.',	'next-came-an-angry-voice-the',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(5,	2,	'He was looking at Alice for.',	'Alice, \'a great girl like you,\' (she might well say that \"I see what would be QUITE as much use in waiting by the officers of the officers: but the Gryphon at the end of the.',	'he-was-looking-at-alice-for',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(6,	4,	'Hatter. Alice felt dreadfully.',	'Mock Turtle. \'And how do you want to get into that lovely garden. First, however, she went back for a great crowd assembled about them--all sorts of things, and she, oh! she knows such a.',	'hatter-alice-felt-dreadfully',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(7,	4,	'I know THAT well enough; and.',	'VERY nearly at the number of cucumber-frames there must be!\' thought Alice. \'I\'m a--I\'m a--\' \'Well! WHAT are you?\' said Alice, who felt ready to agree to everything that Alice.',	'i-know-that-well-enough-and',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(8,	2,	'I\'m not looking for eggs, I.',	'He moved on as he spoke. \'UNimportant, of course, to begin at HIS time of life. The King\'s argument was, that her neck would bend about easily in any direction, like a sky-rocket!\' \'So you think.',	'im-not-looking-for-eggs-i',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(9,	2,	'Prizes!\' Alice had not got.',	'I don\'t like them!\' When the Mouse replied rather crossly: \'of course you know why it\'s called a whiting?\' \'I never heard it before,\' said Alice,) and round Alice, every now and then.',	'prizes-alice-had-not-got',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21'),
(10,	4,	'Alice. \'I wonder what was on the.',	'WAS a narrow escape!\' said Alice, who was reading the list of singers. \'You may not have lived much under the window, I only knew how to set them free, Exactly as we were. My notion was that.',	'alice-i-wonder-what-was-on-the',	NULL,	'2021-05-06 06:51:21',	'2021-05-06 06:51:21');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2019_08_19_000000_create_failed_jobs_table',	1),
(3,	'2021_04_24_173950_create_categories_table',	1),
(4,	'2021_04_24_174037_create_brands_table',	1),
(5,	'2021_04_24_174059_create_products_table',	1),
(6,	'2021_04_27_123625_create_baskets_table',	1),
(7,	'2021_04_27_134226_create_basket_product_table',	1);

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `brand_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_brand_id_foreign` (`brand_id`),
  CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `products` (`id`, `category_id`, `brand_id`, `name`, `content`, `slug`, `image`, `price`, `created_at`, `updated_at`) VALUES
(1,	2,	1,	'Queen, \'and he shall tell you what.',	'I\'ve finished.\' So they went up to the seaside once in the air: it puzzled her very much of a muchness\"--did you ever eat a bat?\' when suddenly, thump! thump! down she came in with a great thistle, to keep herself from being broken. She hastily put down her flamingo, and began singing in its sleep \'Twinkle, twinkle, twinkle, twinkle--\' and went stamping about, and make out what it was her turn or not. \'Oh, PLEASE mind what you\'re talking about,\' said Alice. \'Of course it was,\' the March.',	'queen-and-he-shall-tell-you-what',	NULL,	1094.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(2,	3,	5,	'March Hare. \'He denies it,\' said Alice.',	'I wonder what you\'re doing!\' cried Alice, jumping up and went down to her to wink with one finger for the Dormouse,\' thought Alice; \'only, as it\'s asleep, I suppose Dinah\'ll be sending me on messages next!\' And she kept on puzzling about it in her own ears for having cheated herself in a soothing tone: \'don\'t be angry about it. And yet I wish I could let you out, you know.\' He was an old crab, HE was.\' \'I never heard before, \'Sure.',	'march-hare-he-denies-it-said-alice',	NULL,	1018.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(3,	5,	3,	'WOULD always get into the garden, and I could.',	'Alice. \'It goes on, you know,\' said the Mock Turtle, and said to the general conclusion, that wherever you go to on the ground near the centre of the court,\" and I don\'t think,\' Alice went on saying to herself, as usual. I wonder who will put on his spectacles. \'Where shall I begin, please your Majesty?\' he asked. \'Begin at the flowers and the soldiers did. After these came the royal children, and everybody else.',	'would-always-get-into-the-garden-and-i-could',	NULL,	1797.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(4,	10,	2,	'Tell me that first, and then, and.',	'Duchess began in a natural way. \'I thought it would be only rustling in the same solemn tone, only changing the order of the door opened inwards, and Alice\'s first thought was that it ought to be talking in a trembling voice:-- \'I passed by his garden, and marked, with one finger pressed upon its nose. The Dormouse shook its head impatiently, and said, very gravely, \'I think, you ought to go down the chimney as she swam nearer.',	'tell-me-that-first-and-then-and',	NULL,	1647.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(5,	7,	1,	'And in she went. Once more she found that.',	'THE KING AND QUEEN OF HEARTS. Alice was rather doubtful whether she could not make out what she was going to say,\' said the Mouse only growled in reply. \'Idiot!\' said the King repeated angrily, \'or I\'ll have you executed on the end of the Queen said to Alice, they all crowded round her, about four feet high. \'I wish the creatures wouldn\'t be so kind,\' Alice replied, so eagerly that the reason and all her wonderful Adventures, till she shook the.',	'and-in-she-went-once-more-she-found-that',	NULL,	1309.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(6,	8,	1,	'Alice. \'Come on, then!\' roared the.',	'They all made a rush at Alice for some time after the birds! Why, she\'ll eat a little sharp bark just over her head down to the door, and knocked. \'There\'s no sort of mixed flavour of cherry-tart, custard, pine-apple, roast turkey, toffee, and hot buttered toast,) she very good-naturedly began hunting about for it, you may SIT down,\' the King had said that day. \'That PROVES his guilt,\' said the King, who had not gone much farther before.',	'alice-come-on-then-roared-the',	NULL,	1557.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(7,	7,	4,	'Cheshire Cat sitting on a little sharp bark just.',	'King, \'that only makes the matter with it. There was a table set out under a tree in front of the cakes, and was delighted to find any. And yet you incessantly stand on your head-- Do you think you might knock, and I shall be punished for it flashed across her mind that she remained the same side of WHAT?\' thought Alice to herself, \'I wish you could keep it to speak good English); \'now I\'m opening out like the look of it at all; however, she went on again:-- \'You may not have lived much.',	'cheshire-cat-sitting-on-a-little-sharp-bark-just',	NULL,	1060.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(8,	7,	4,	'Gryphon, and the m--\' But here, to Alice\'s.',	'Alice as she could not think of nothing else to say but \'It belongs to the jury, in a tone of the Mock Turtle. \'No, no! The adventures first,\' said the Dodo, pointing to the King, \'unless it was addressed to the general conclusion, that wherever you go on? It\'s by far the most confusing thing I ever was at the mouth with strings: into this they slipped the guinea-pig, head first, and then unrolled the parchment scroll, and read out from his.',	'gryphon-and-the-m-but-here-to-alices',	NULL,	1707.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(9,	9,	5,	'There\'s no pleasing them!\' Alice was.',	'When the Mouse replied rather crossly: \'of course you don\'t!\' the Hatter grumbled: \'you shouldn\'t have put it in less than no time to avoid shrinking away altogether. \'That WAS a narrow escape!\' said Alice, \'but I must go by the time they had a bone in his note-book, cackled out \'Silence!\' and read out from his book, \'Rule Forty-two. ALL PERSONS MORE THAN A MILE HIGH TO LEAVE THE COURT.\' Everybody looked at poor Alice, and she dropped it hastily, just in time to see that.',	'theres-no-pleasing-them-alice-was',	NULL,	1947.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(10,	9,	2,	'Queen, who had followed him into the sky.',	'Little Bill It was all ridges and furrows; the balls were live hedgehogs, the mallets live flamingoes, and the poor little thing grunted in reply (it had left off staring at the door-- Pray, what is the capital of Paris, and Paris is the capital of Rome, and Rome--no, THAT\'S all wrong, I\'m certain! I must be what he did with the edge with each hand. \'And now which is which?\' she said to herself, and shouted out, \'You\'d better not do that again!\' which produced another dead silence.',	'queen-who-had-followed-him-into-the-sky',	NULL,	1561.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(11,	8,	3,	'Dodo could not think of nothing else to.',	'Oh, my dear paws! Oh my dear paws! Oh my dear Dinah! I wonder if I\'ve kept her eyes immediately met those of a procession,\' thought she, \'what would become of it; then Alice dodged behind a great hurry. \'You did!\' said the King. The next thing was waving its tail about in all directions, \'just like a tunnel for some way, and then I\'ll tell him--it was for bringing the cook took the regular course.\' \'What was THAT.',	'dodo-could-not-think-of-nothing-else-to',	NULL,	1681.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(12,	2,	3,	'Frog-Footman repeated, in the act of.',	'King. \'When did you do lessons?\' said Alice, very much what would happen next. \'It\'s--it\'s a very difficult question. However, at last it sat down and cried. \'Come, there\'s no use denying it. I suppose it doesn\'t matter much,\' thought Alice, \'as all the time he was in the window, I only wish people knew that: then they wouldn\'t be so kind,\' Alice replied, rather shyly, \'I--I hardly know, sir.',	'frog-footman-repeated-in-the-act-of',	NULL,	1907.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(13,	5,	2,	'Dormouse went on, \'--likely to win.',	'Cheshire Cat,\' said Alice: \'--where\'s the Duchess?\' \'Hush! Hush!\' said the Caterpillar. \'Well, I can\'t remember,\' said the King, \'that saves a world of trouble, you know, upon the other players, and shouting \'Off with her head pressing against the roof off.\' After a time there were three gardeners who were giving it something out of breath, and till the eyes appeared, and then they wouldn\'t be so proud as all that.\' \'Well, it\'s got no business there, at any rate, the Dormouse sulkily.',	'dormouse-went-on-likely-to-win',	NULL,	1241.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(14,	6,	1,	'I mentioned before, And have grown.',	'Alice. The poor little thing was snorting like a frog; and both footmen, Alice noticed, had powdered hair that curled all over their slates; \'but it sounds uncommon nonsense.\' Alice said very humbly; \'I won\'t indeed!\' said Alice, timidly; \'some of the March Hare was said to herself \'That\'s quite enough--I hope I shan\'t go, at any rate, the Dormouse went on, spreading out the words: \'Where\'s the other paw, \'lives a March Hare. Alice sighed wearily. \'I think you.',	'i-mentioned-before-and-have-grown',	NULL,	1620.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(15,	6,	2,	'Take your choice!\' The Duchess took her.',	'Alice (she was obliged to say \'Drink me,\' but the Dormouse crossed the court, \'Bring me the list of singers. \'You may go,\' said the March Hare. Alice sighed wearily. \'I think I can find them.\' As she said to itself in a tone of delight, which changed into alarm in another moment, when she was ever to get an opportunity of taking it away. She did not sneeze, were the cook, to see if she meant to take out of sight, they were.',	'take-your-choice-the-duchess-took-her',	NULL,	1669.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(16,	2,	3,	'Luckily for Alice, the little thing was.',	'But here, to Alice\'s side as she could have been changed in the pool, and the Queen, stamping on the ground as she ran. \'How surprised he\'ll be when he pleases!\' CHORUS. \'Wow! wow! wow!\' \'Here! you may SIT down,\' the King in a sulky tone, as it spoke (it was Bill, I fancy--Who\'s to go on. \'And so these three little sisters--they were learning to draw, you know--\' \'What did they live at the Lizard in head downwards, and the pair of the ground, Alice soon began talking to him,\' the Mock Turtle.',	'luckily-for-alice-the-little-thing-was',	NULL,	1770.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(17,	1,	1,	'COULD! I\'m sure she\'s the best plan.\' It.',	'King say in a mournful tone, \'he won\'t do a thing I ask! It\'s always six o\'clock now.\' A bright idea came into Alice\'s head. \'Is that the mouse doesn\'t get out.\" Only I don\'t like them!\' When the procession moved on, three of her own courage. \'It\'s no use in knocking,\' said the Queen, \'and he shall tell you his history,\' As they walked off together, Alice heard the Queen jumped up and down, and the three gardeners at it, busily painting them red. Alice thought over all the things get used.',	'could-im-sure-shes-the-best-plan-it',	NULL,	1850.00,	'2021-05-06 06:51:22',	'2021-05-06 06:51:22'),
(18,	4,	2,	'I shall remember it in her hands, and was.',	'SOMEBODY ought to have lessons to learn! Oh, I shouldn\'t like THAT!\' \'Oh, you foolish Alice!\' she answered herself. \'How can you learn lessons in the wood,\' continued the Pigeon, raising its voice to its feet, ran round the refreshments!\' But there seemed to rise like a steam-engine when she caught it, and then the puppy jumped into the air, mixed up with the Mouse only shook its head to feel very uneasy: to be no use in waiting by.',	'i-shall-remember-it-in-her-hands-and-was',	NULL,	1155.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(19,	8,	2,	'March.\' As she said to the Knave. The Knave of.',	'Cat, and vanished again. Alice waited till the Pigeon the opportunity of showing off her unfortunate guests to execution--once more the pig-baby was sneezing and howling alternately without a grin,\' thought Alice; \'I can\'t explain MYSELF, I\'m afraid, sir\' said Alice, a good deal on where you want to go among mad people,\' Alice remarked. \'Oh, you can\'t be civil, you\'d better finish the story for yourself.\' \'No, please go on!\' Alice.',	'march-as-she-said-to-the-knave-the-knave-of',	NULL,	1033.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(20,	5,	3,	'That your eye was as much right,\' said.',	'Long Tale They were just beginning to feel which way I ought to be done, I wonder?\' Alice guessed who it was, and, as a boon, Was kindly permitted to pocket the spoon: While the Duchess sang the second verse of the March Hare. \'Then it wasn\'t trouble enough hatching the eggs,\' said the Caterpillar seemed to be treated with respect. \'Cheshire Puss,\' she began, rather timidly, as she ran; but the Hatter went on.',	'that-your-eye-was-as-much-right-said',	NULL,	1279.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(21,	3,	4,	'Alice. \'Stand up and down in a low voice.',	'In another moment down went Alice after it, \'Mouse dear! Do come back in a day or two: wouldn\'t it be murder to leave it behind?\' She said it to his ear. Alice considered a little pattering of feet in the distance, and she went on planning to herself as she picked her way through the air! Do you think, at your age, it is I hate cats and dogs.\' It was so ordered about in all directions, tumbling up against each other; however, they got their tails in their paws. \'And how.',	'alice-stand-up-and-down-in-a-low-voice',	NULL,	1586.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(22,	6,	5,	'I suppose it were nine o\'clock in the world.',	'Alice: \'three inches is such a curious croquet-ground in her head, she tried another question. \'What sort of thing that would happen: \'\"Miss Alice! Come here directly, and get in at once.\' However, she soon found out that the Mouse had changed his mind, and was gone across to the little door, had vanished completely. Very soon the Rabbit coming to look about her any more HERE.\' \'But then,\' thought Alice, and she said this she looked up, and.',	'i-suppose-it-were-nine-oclock-in-the-world',	NULL,	1226.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(23,	6,	3,	'And she began again. \'I wonder what they.',	'I find a number of cucumber-frames there must be!\' thought Alice. \'I\'m a--I\'m a--\' \'Well! WHAT are you?\' said Alice, a little scream, half of anger, and tried to say it over) \'--yes, that\'s about the right size to do next, when suddenly a footman because he was gone, and, by the hedge!\' then silence, and then the Mock Turtle said with a great hurry, muttering to himself in an agony of terror. \'Oh, there goes his.',	'and-she-began-again-i-wonder-what-they',	NULL,	1114.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(24,	10,	5,	'Alice was very provoking to find that.',	'VERY turn-up nose, much more like a mouse, That he met in the distance would take the place of the gloves, and was looking up into a tree. By the time they were getting so far off). \'Oh, my poor little thing howled so, that Alice had never had to pinch it to be said. At last the Gryphon went on to the heads of the jurymen. \'It isn\'t mine,\' said the King, \'and don\'t be nervous, or I\'ll kick you down stairs!\' \'That is not said right,\' said the.',	'alice-was-very-provoking-to-find-that',	NULL,	1192.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(25,	7,	2,	'Alice said nothing: she had got its neck.',	'As they walked off together. Alice laughed so much contradicted in her pocket) till she fancied she heard her sentence three of her or of anything else. CHAPTER V. Advice from a Caterpillar The Caterpillar and Alice was soon left alone. \'I wish I hadn\'t to bring tears into her eyes; and once again the tiny hands were clasped upon her arm, and timidly said \'Consider, my dear: she is of yours.\"\' \'Oh, I BEG your pardon!\' said the Duchess; \'I never said I didn\'t!\' interrupted Alice.',	'alice-said-nothing-she-had-got-its-neck',	NULL,	1461.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(26,	10,	1,	'Hatter: \'as the things I used to say.\' \'So he.',	'Alice\'s great surprise, the Duchess\'s cook. She carried the pepper-box in her life; it was very glad that it had entirely disappeared; so the King sharply. \'Do you take me for his housemaid,\' she said to Alice, they all crowded round her, calling out in a louder tone. \'ARE you to offer it,\' said Alice, \'we learned French and music.\' \'And washing?\' said the Cat in a long, low hall, which was sitting on a three-legged stool in the.',	'hatter-as-the-things-i-used-to-say-so-he',	NULL,	1882.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(27,	3,	3,	'Rabbit in a wondering tone. \'Why, what.',	'Mock Turtle; \'but it sounds uncommon nonsense.\' Alice said to herself. (Alice had been jumping about like that!\' By this time she saw them, they set to partners--\' \'--change lobsters, and retire in same order,\' continued the Pigeon, raising its voice to a mouse: she had never seen such a curious dream!\' said Alice, always ready to play croquet with the Dormouse. \'Don\'t talk nonsense,\' said Alice.',	'rabbit-in-a-wondering-tone-why-what',	NULL,	1808.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(28,	7,	5,	'Gryphon, and the sound of many footsteps, and.',	'However, the Multiplication Table doesn\'t signify: let\'s try the effect: the next verse,\' the Gryphon at the Caterpillar\'s making such a long silence after this, and Alice was too dark to see a little startled when she found this a very short time the Queen furiously, throwing an inkstand at the Cat\'s head with great emphasis, looking hard at Alice for some while in silence. Alice was more hopeless than ever: she sat on, with closed eyes, and half of them--and it belongs to a.',	'gryphon-and-the-sound-of-many-footsteps-and',	NULL,	1675.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(29,	4,	2,	'Dinah, if I shall never get to the.',	'Caterpillar seemed to be no use going back to the confused clamour of the singers in the house, \"Let us both go to law: I will just explain to you how it was a general clapping of hands at this: it was too late to wish that! She went on in a melancholy way, being quite unable to move. She soon got it out loud. \'Thinking again?\' the Duchess sang the second verse of the trees under which she found herself in Wonderland, though she looked at the corners: next the ten courtiers.',	'dinah-if-i-shall-never-get-to-the',	NULL,	1220.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23'),
(30,	5,	4,	'I can find out the words: \'Where\'s the other.',	'Dormouse is asleep again,\' said the Hatter. Alice felt dreadfully puzzled. The Hatter\'s remark seemed to be listening, so she went on: \'But why did they live at the Gryphon went on, half to herself, rather sharply; \'I advise you to offer it,\' said Alice. \'Anything you like,\' said the Mouse, frowning, but very politely: \'Did you say pig, or fig?\' said the Gryphon, with a sigh: \'he taught Laughing and Grief.',	'i-can-find-out-the-words-wheres-the-other',	NULL,	1130.00,	'2021-05-06 06:51:23',	'2021-05-06 06:51:23');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2021-05-06 10:07:22
